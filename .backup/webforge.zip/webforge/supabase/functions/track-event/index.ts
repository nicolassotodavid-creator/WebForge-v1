// track-event — Contrato: ARQUITECTURA_webforge_v2.md sec. 8
// Input: { lead_id, type, payload }. Inserta en events. Si type='demo_viewed' -> lead status='viewed'.
import { createClient } from "jsr:@supabase/supabase-js@2";

Deno.serve(async (_req) => {
  // TODO Fase 8: insertar evento; si demo_viewed, actualizar status del lead.
  const _supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );
  return new Response("TODO: implementar track-event", { status: 501 });
});

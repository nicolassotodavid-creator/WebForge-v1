// send-email — Contrato: ARQUITECTURA_webforge_v2.md sec. 8
// Input: { message_id }. Envía vía Resend desde FROM_EMAIL (dominio secundario). -> status='sent'.
Deno.serve(async (_req) => {
  // TODO Fase 5: cargar outreach_message, enviar con RESEND_API_KEY, marcar sent + event message_sent.
  return new Response("TODO: implementar send-email", { status: 501 });
});

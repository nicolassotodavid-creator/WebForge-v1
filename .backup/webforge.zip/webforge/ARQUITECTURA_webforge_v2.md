# WebForge — Arquitectura v2 (build spec para Fable / Claude Code)

> Sistema de captación que cada día: scrapea negocios locales, les construye una **web a
> medida** (Lovable conducido por Claude vía MCP), te deja revisarlas, y dispara el contacto
> (mensaje + llamada de ElevenLabs) para que reserven/acepten y paguen.
>
> Codename: `webforge`. Esta v2 **sustituye** a la v1 (el motor de webs cambia de plantillas
> a Lovable-por-cliente vía MCP).

---

## 0. Cómo usar este documento

Es la fuente de verdad para Fable (como Claude Code en VS Code). Léelo entero antes de tocar
nada. Construye **por fases** (sección 13), verificando cada una antes de seguir. Copia la
sección 14 (`CLAUDE.md`) a la raíz del repo. El arranque y el super-prompt están en 15 y 16.

---

## 1. Decisión arquitectónica clave

**Las webs de cliente se construyen en Lovable, conducido por Claude (Fable) vía el MCP de Lovable.**
Lovable expone un servidor MCP que deja a un agente crear proyectos, iterar, lanzar deploy y
recuperar una **URL en vivo**, todo programático (OAuth, sin API-key). Eso es el primitivo que
convierte "web a medida" en algo automatizable a 5/día.

Hay **dos backends distintos**, no los confundas:

- **La App** = tu panel + Supabase (DB, Auth, Edge Functions). Es lo que TÚ operas. Vive en
  Supabase, la construyes en VS Code. No usa Lovable.
- **El Orquestador** = un agente que corre por cron (Fable + MCP de Lovable). Es el que cada
  mañana scrapea → analiza → **construye las webs en Lovable** → guarda las URLs en Supabase.

Modelo de entrega: **web-first**. La web a medida se construye ANTES de contactar y es el gancho
(la enseñas en el mensaje/llamada). Cuando el cliente acepta y paga, esa misma web pasa a ser la
suya (apuntas su dominio / la mantienes). Implicación de coste en sección 17.

---

## 2. Las dos caras de Fable (no las mezcles)

Fable se usa en dos sitios totalmente distintos:

1. **Fable como desarrollador** (en VS Code, vía Claude Code): escribe TODO el código del
   sistema —la App y el Orquestador—. Es quien construye el proyecto siguiendo este doc.
2. **Fable como cerebro del Orquestador** (en producción): el modelo que, dentro del agente
   diario, redacta los briefs, compone los build-prompts y conduce Lovable por MCP.

Mismo modelo, dos roles. La sección 16 (super-prompt) es para el rol 1.

---

## 3. Stack (cerrado)

| Capa | Tecnología |
|---|---|
| Construir el sistema | **Fable vía Claude Code** en VS Code (suscripción Max, plano; NO pongas `ANTHROPIC_API_KEY` en ese entorno o factura por token) |
| App: frontend | React + Vite + Tailwind + shadcn/ui, desplegado en **Vercel** (free) |
| App: backend/DB | **Supabase** (Postgres + Auth + Storage + **Edge Functions** Deno + **pg_cron**) |
| Motor de webs de cliente | **Lovable** conducido por su **MCP** desde el Orquestador |
| Orquestador (agente diario) | Node/TS con **Claude Agent SDK** (o Claude Code headless) + **MCP de Lovable**, modelo `claude-fable-5`, en un **VPS** por cron |
| LLM en runtime | **Claude API**: `claude-fable-5` (briefs, build-prompts, orquestación), `claude-haiku-4-5-20251001` (extracción barata a volumen) |
| Email | **Resend** (transaccional, **dominio secundario**, texto plano) |
| Pagos | **Stripe Checkout** |
| Llamadas salientes | **ElevenLabs Agents** (la voz/telefonía; NO se hace con Claude/Lovable) |
| Scraping | Externo (Apify "Businesses Without Websites" / Outscraper) → ingest |

**Routing de modelos (coste):** Fable 5 es potente pero caro (~$10/$50 por millón de tokens),
úsalo donde su calidad manda: el build-prompt (determina la calidad de la web) y conducir Lovable.
Para extracción masiva de reseñas, Haiku 4.5. Sonnet 4.6 como alternativa más barata al build-prompt
si Fable se dispara en coste. Activa **prompt caching** en los system prompts.

---

## 4. Arquitectura de componentes

```
                 ┌─────────────────────────────────────────────┐
   (cron diario) │  ORQUESTADOR  (VPS · Agent SDK · Fable)      │
                 │  1. lee leads 'new' de Supabase             │
   Scraper ─────►│  2. Fable: brief + build-prompt             │
   (Apify)       │  3. MCP Lovable: construye web → live_url    │──► Lovable (webs de cliente)
                 │  4. escribe brief + site en Supabase        │
                 └───────────────┬─────────────────────────────┘
                                 │  (service role)
                                 ▼
        ┌───────────────────────────────────────────────┐
        │  SUPABASE  (DB · Auth · Edge Functions)        │
        │  leads · briefs · sites · outreach · bookings  │◄────── Stripe (webhook)
        └───────────────┬───────────────────────────────┘
                        │
            ┌───────────┴────────────┐
            ▼                        ▼
   APP / Panel (Vercel)      Páginas públicas (Vercel)
   - dashboard pipeline       - /book/:leadId  (acepta+paga)
   - QA: revisar/aprobar       - /gracias
   - contacto (wa.me/email)   (la "demo" = la URL de Lovable)
            │
            ▼
   ElevenLabs (llamadas a leads aprobados)
```

---

## 5. Modelo de datos (Supabase / Postgres)

DDL completo (self-contained). El cambio principal vs v1: la tabla `demos` se sustituye por `sites`
(proyecto Lovable + URL), y el pipeline añade el gate de aprobación.

```sql
-- LEADS: negocios scrapeados
create table leads (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text, phone text, whatsapp text, email text,
  address text, city text, country text default 'ES',
  google_place_id text unique,
  rating numeric, review_count int,
  has_website boolean default false,
  raw_json jsonb,                 -- payload bruto del scraper (incluye reviews)
  source text,                    -- 'apify' | 'outscraper' | 'manual'
  status text not null default 'new',  -- máquina de estados (sección 7)
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index on leads (status);
create index on leads (city, category);

-- BRIEFS: salida del análisis (Fable/Haiku)
create table briefs (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id) on delete cascade,
  business_summary text, tone text,
  value_props jsonb, highlights_from_reviews jsonb,
  recommended_sections jsonb, services jsonb,
  suggested_palette jsonb, hero_copy text,
  model_used text, created_at timestamptz default now()
);
create index on briefs (lead_id);

-- SITES: la web a medida construida en Lovable
create table sites (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id) on delete cascade,
  lovable_project_id text,        -- id del proyecto en Lovable (vía MCP)
  live_url text,                  -- URL en vivo que devuelve Lovable
  build_prompt text,              -- prompt enviado a Lovable
  status text default 'queued',   -- queued|building|built|failed|approved|rejected|delivered
  credits_estimate numeric,       -- créditos aprox (si el MCP lo reporta)
  notes text,                     -- feedback del operador en QA
  created_at timestamptz default now(),
  built_at timestamptz, approved_at timestamptz
);
create index on sites (lead_id);
create index on sites (status);

-- OUTREACH: mensajes redactados (WhatsApp/email)
create table outreach_messages (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id) on delete cascade,
  channel text not null,          -- 'whatsapp' | 'email'
  subject text, body text not null,
  status text default 'draft',    -- draft|sent|replied|bounced
  generated_by_model text, sent_at timestamptz,
  created_at timestamptz default now()
);
create index on outreach_messages (lead_id);

-- BOOKINGS: aceptaciones/reservas desde /book
create table bookings (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id) on delete set null,
  site_id uuid references sites(id) on delete set null,
  name text, email text, phone text,
  plan text, deposit_amount int,          -- céntimos
  stripe_session_id text,
  stripe_payment_status text default 'pending',  -- pending|paid|failed
  scheduled_at timestamptz,
  status text default 'started',          -- started|paid|cancelled
  created_at timestamptz default now()
);

-- EVENTS: auditoría/analítica
create table events (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references leads(id) on delete cascade,
  type text not null,             -- demo_viewed|message_sent|call_made|booking_started|payment_succeeded...
  payload jsonb, created_at timestamptz default now()
);
create index on events (lead_id, type);

-- APP_CONFIG: ajustes del operador (singleton)
create table app_config (
  id int primary key default 1,
  from_email text, sender_domain text,
  default_plan text, plan_prices jsonb,   -- {basico: 49900, pro: 99900}
  booking_base_url text,                  -- p.ej. https://app.webforge.io/book
  updated_at timestamptz default now()
);
```

### RLS

```sql
alter table leads enable row level security;
alter table briefs enable row level security;
alter table sites enable row level security;
alter table outreach_messages enable row level security;
alter table bookings enable row level security;
alter table events enable row level security;

-- Operador autenticado: acceso total al back-office
create policy op_leads on leads             for all using (auth.role()='authenticated');
create policy op_briefs on briefs           for all using (auth.role()='authenticated');
create policy op_sites on sites             for all using (auth.role()='authenticated');
create policy op_msgs on outreach_messages  for all using (auth.role()='authenticated');
create policy op_book on bookings           for all using (auth.role()='authenticated');

-- Inserts públicos (booking) van por Edge Function con service_role. El front público no escribe directo.
-- El Orquestador escribe con service_role (bypassa RLS).
```

> Regla de oro: ANTHROPIC_API_KEY, Resend, Stripe, ElevenLabs, OAuth de Lovable y la service key
> viven SOLO en el servidor (Edge Functions / Orquestador). Nada de claves en el frontend.

---

## 6. (RLS incluida arriba)

---

## 7. Máquina de estados del lead (`leads.status`)

```
new ──► analyzed ──► site_built ──►[QA]──► approved ──► contacted ──► viewed ──► booked ──► won
                                     │                      │                       │
                                  rejected               (sin respuesta) ──► nurture / lost
```

| Estado | Lo pone | Significa |
|---|---|---|
| `new` | ingest-leads | Scrapeado, sin procesar |
| `analyzed` | orquestador | Brief generado |
| `site_built` | orquestador | Web construida en Lovable, URL guardada |
| `approved` / `rejected` | **operador (QA)** | Visto bueno humano para contactar (o descartado) |
| `contacted` | operador | Mensaje enviado / llamada hecha |
| `viewed` | track-event | Abrió la web |
| `booked` | create-checkout | Inició aceptación |
| `won` | stripe-webhook | Pagó |
| `nurture`/`lost` | operador/cron | Sin respuesta / descartado |

**El gate de QA (`site_built → approved`) es obligatorio**: nada se contacta sin tu visto bueno.

---

## 8. Edge Functions de la App (contratos)

El paso "construir web" NO es una Edge Function (vive en el Orquestador). La App solo tiene plumbing síncrono.

| Función | Trigger | Input | Hace |
|---|---|---|---|
| `ingest-leads` | Webhook scraper / import | `{leads:[...]}` o CSV | Normaliza, dedupe por `google_place_id`, upsert → `status=new` |
| `generate-outreach` | Operador (tras aprobar) | `{lead_id, channel}` | Brief + `live_url` → Claude redacta mensaje plano con la URL → `outreach_messages` draft |
| `send-email` | Operador | `{message_id}` | Envía vía Resend (dominio secundario) → event `message_sent` |
| `create-checkout` | Página `/book` | `{lead_id, plan, contact}` | Crea Stripe Checkout, inserta `bookings` started → `status=booked` |
| `stripe-webhook` | Stripe | evento firmado | `checkout.session.completed` → `booking.paid`, lead `won` |
| `track-event` | Front público | `{lead_id, type, payload}` | Inserta en `events` (p.ej. `demo_viewed`) → `status=viewed` si aplica |

> `analyze-lead` es opcional como Edge Function para poder probar el brief aislado. En producción
> el brief lo hace el Orquestador con el mismo prompt de `_shared/prompts.ts`.

---

## 9. El Orquestador (el agente diario) — pieza nueva

Es lo que hace que todo sea automático. **No** es un cron de `curl`: es un agente con estado que
sostiene la sesión OAuth del MCP de Lovable.

**Cómo corre:** script Node/TS usando el **Claude Agent SDK** (o Claude Code en modo no-interactivo),
con el **MCP de Lovable** configurado (OAuth), modelo `claude-fable-5` y la **service key de Supabase**.
Agendado por **cron en un VPS** (un build de Lovable tarda minutos, así que NADA de funciones
serverless con timeout corto: VPS o job largo). Alternativa: GitHub Actions con workflow programado.

**Pseudo-flujo (`orquestador/run.ts`):**
```ts
const BATCH = 5; // webs/día
const leads = await db.from('leads').select('*').eq('status','new').limit(BATCH);

for (const lead of leads) {
  // 1) Brief
  const brief = await fable(BRIEF_PROMPT, leadConReviews);   // JSON estricto
  await db.from('briefs').insert({ lead_id: lead.id, ...brief, model_used:'claude-fable-5' });
  await db.from('leads').update({ status:'analyzed' }).eq('id', lead.id);

  // 2) Build-prompt (Fable escribe el prompt para Lovable a partir del brief)
  const buildPrompt = await fable(BUILD_PROMPT, { brief, lead,
      booking_url: `${BOOKING_BASE}?lead=${lead.id}` });

  // 3) Construir en Lovable VÍA MCP → URL en vivo
  const site = await db.from('sites').insert({ lead_id:lead.id, build_prompt:buildPrompt, status:'building' }).select().single();
  const { projectId, liveUrl } = await lovableMcp.createProject({ prompt: buildPrompt }); // herramienta MCP
  await db.from('sites').update({ lovable_project_id:projectId, live_url:liveUrl, status:'built', built_at:'now()' }).eq('id', site.id);

  // 4) Marcar lead listo para QA
  await db.from('leads').update({ status:'site_built' }).eq('id', lead.id);
}
// Las aprobaciones, el outreach y las llamadas son pasos POSTERIORES (tras el QA humano).
```

**Consistencia de marca:** fija una sola vez el *workspace/project knowledge* en Lovable (vía MCP)
con tu sistema de diseño, tono y patrones, para que cada build salga consistente sin supervisión pesada.

**El build-prompt** (lo genera Fable) debe instruir a Lovable: one-page a medida para `[negocio]`,
secciones del brief, paleta, **reseñas reales**, horario/contacto, mobile-first y rápida, y un CTA
prominente **"Reservar / Aceptar"** que enlace a `{booking_url}` (lleva el `lead_id`). Opcional:
inyectar un snippet `fetch` a `track-event` en el `onLoad` para registrar `demo_viewed`.

---

## 10. Esquemas de salida de Claude (JSON estricto)

**Brief:**
```json
{ "business_summary":"string","tone":"string","value_props":["string"],
  "highlights_from_reviews":["string"],
  "recommended_sections":["hero","servicios","resenas","galeria","reserva","contacto"],
  "services":[{"name":"string","desc":"string"}],
  "suggested_palette":{"primary":"#hex","accent":"#hex","bg":"#hex"},
  "hero_copy":"string" }
```

**Build-prompt:** salida = **texto** (el prompt para Lovable), no JSON. Reglas de calidad en sección 9.

**Outreach:**
```json
{ "channel":"whatsapp|email","subject":"string|null",
  "body":"string (texto plano, humano, corto, menciona reseñas reales, incluye la live_url)" }
```

> Mensaje en frío: texto plano, 1ª persona, sin pinta de plantilla. Lo bonito es la web, no el mensaje.

---

## 11. Frontend (la App)

### Back-office (auth)
- **`/` Dashboard** — pipeline por estado, contadores, filtros por ciudad/categoría/estado.
- **`/leads/:id` Detalle + QA** — info + reseñas + brief + **iframe/preview de la `live_url` de Lovable**;
  botones **Aprobar** / **Rechazar** / **Regenerar** (re-encola el build). Tras aprobar: bloque de
  contacto con el mensaje redactado, **Copiar** + **Abrir WhatsApp** (`wa.me/<phone>?text=<body>`),
  **Marcar contactado**, y para email **Enviar** (→ `send-email`). Estado de booking.
- **`/import`** — pegar JSON del scraper / CSV / config del webhook de ingest.
- **`/settings`** — dominio remitente, planes/precios, `booking_base_url`.

### Público (sin auth)
- La **"demo"** que ve el prospecto **es la URL de Lovable** (no la renderiza tu app).
- **`/book/:leadId`** — formulario de aceptación → `create-checkout` → Stripe.
- **`/gracias`** — confirmación tras pago.

---

## 12. Secrets / variables de entorno (solo servidor)

```
# Claude (runtime, en Orquestador y Edge Functions)
ANTHROPIC_API_KEY=
# Lovable MCP: OAuth (se conecta vía connector/SDK, no es key plana) — sesión en el Orquestador
# Supabase: SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY (en Orquestador y funciones)
SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
# Email
RESEND_API_KEY=
FROM_EMAIL=hola@trywebforge-mail.com     # DOMINIO SECUNDARIO
# Pagos
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
# Scraper
APIFY_TOKEN=                              # o OUTSCRAPER_API_KEY
INGEST_WEBHOOK_SECRET=
# Llamadas
ELEVENLABS_API_KEY=
ELEVENLABS_AGENT_ID=
# Orquestador
BATCH_SIZE=5
BOOKING_BASE=https://app.webforge.io/book
```

---

## 13. Orden de construcción (para Fable)

Fase a fase, verificando cada una.

- **Fase 0 — Scaffold.** Repo + Vite/React/Tailwind/shadcn + Supabase. Aplicar migración (sección 5, schema+RLS). Auth (solo tú). Deploy en Vercel. Cargar secrets.
- **Fase 1 — Ingest + datos.** `ingest-leads` + `/import` + tabla de leads en `/`. Meter leads reales.
- **Fase 2 — Brief.** Prompt en `_shared/prompts.ts` + `analyze-lead` (Edge Fn de prueba) + render del brief en `/leads/:id`.
- **Fase 3 — Orquestador MVP (núcleo nuevo).** Script Node + Agent SDK + **MCP de Lovable** + Fable que, para UN lead, genere brief → build-prompt → **construya la web en Lovable** → guarde `live_url` en `sites`. Verificar que devuelve una URL viva.
- **Fase 4 — Dashboard QA.** Preview de la `live_url` en `/leads/:id` + Aprobar/Rechazar/Regenerar.
- **Fase 5 — Outreach.** `generate-outreach` + acciones (copiar / WhatsApp / contactado) + `send-email` (Resend).
- **Fase 6 — Booking + pagos.** `/book/:leadId` + `create-checkout` + `stripe-webhook` + `/gracias`.
- **Fase 7 — Llamadas.** ElevenLabs Agents salientes para leads `approved` (ver aviso de compliance en 17).
- **Fase 8 — Automatización diaria.** Cron del Orquestador en lote (5/día) + `track-event` + métricas en el dashboard.

---

## 14. CLAUDE.md (copiar a la raíz del repo)

```md
# WebForge — instrucciones para Fable / Claude Code

Dos backends: (1) APP = panel React (Vercel) + Supabase (Postgres+Auth+Edge Functions Deno+pg_cron).
(2) ORQUESTADOR = agente Node (Claude Agent SDK + MCP de Lovable + modelo claude-fable-5) en VPS por cron,
que construye las webs de cliente en Lovable y escribe en Supabase con la service key.

Reglas duras:
- Secrets (ANTHROPIC_API_KEY, Resend, Stripe, ElevenLabs, OAuth Lovable, service key) SOLO en servidor. Nunca en el frontend.
- Las webs de cliente se construyen en Lovable VÍA SU MCP desde el Orquestador. NO como Edge Function. NO plantillas estáticas.
- El front público no inserta en DB directo: pasa por create-checkout / track-event.
- Salidas de Claude en JSON estricto (esquemas en ARQUITECTURA_webforge_v2.md sec. 10). Parsear con try/catch.
- Modelos: Haiku 4.5 extracción a volumen; Fable 5 para build-prompt y conducir Lovable; Sonnet 4.6 alternativa barata. Prompt caching en system prompts.
- Gate de QA obligatorio: nada se contacta hasta status='approved' (visto bueno humano).
- Mensaje en frío: texto plano, humano, corto, con reseñas reales y la live_url. Sin pinta de plantilla.
- Construir por fases (sec. 13). Verificar cada fase antes de seguir.

Fuera de alcance (no construir): llamadas con Claude/Lovable (eso es ElevenLabs); WhatsApp masivo en frío.
```

---

## 15. Cómo empezar (paso a paso)

**A. Cuentas y llaves (una tarde):**
1. **Anthropic** — plan **Max** (para construir con Claude Code en plano) + una **API key** aparte para el runtime (Orquestador/Edge Functions).
2. **Supabase** — proyecto nuevo (tier free vale para el MVP).
3. **Lovable** — cuenta con créditos (plan acorde a tu volumen, ver sec. 17) y **activa el MCP**.
4. **Resend** — alta + verifica un **dominio secundario** para email.
5. **Stripe** — cuenta + claves test.
6. **Scraper** — Apify (actor "Businesses Without Websites") u Outscraper.
7. **ElevenLabs** — cuenta + un Agent (para las llamadas, Fase 7).
8. **VPS** barato (Hetzner/DigitalOcean ~5€) para el cron del Orquestador.

**B. Conectar el MCP de Lovable a Claude:** en los ajustes de connectors de Claude, añade Lovable
(OAuth). Así Fable puede conducir Lovable. (El Orquestador en producción usa esa misma conexión vía SDK.)

**C. Arrancar el repo:**
1. Crea el repo y mete este doc (`ARQUITECTURA_webforge_v2.md`) + el `CLAUDE.md` (sec. 14) en la raíz.
2. Ábrelo en VS Code, lanza **Claude Code** con **Fable** seleccionado. (Asegúrate de NO tener
   `ANTHROPIC_API_KEY` en ese entorno, o Code factura por token en vez de tu plan.)
3. Pega el **super-prompt** (sección 16). Fable construye Fase 0 + 1 y para para que verifiques.
4. Avanza fase a fase dándole el OK.

---

## 16. Super-prompt para Fable (copia y pega en Claude Code)

```
Eres el desarrollador principal de WebForge, un sistema que cada día scrapea negocios locales,
les construye una web a medida y dispara el contacto para que reserven/acepten y paguen.

Antes de escribir nada, lee por completo ARQUITECTURA_webforge_v2.md y CLAUDE.md en la raíz del repo.
Son la fuente de verdad: síguelos al pie de la letra.

Stack cerrado:
- Dos backends: (1) APP = React+Vite+Tailwind+shadcn en Vercel + Supabase (Postgres + Auth +
  Edge Functions en Deno + pg_cron). (2) ORQUESTADOR = agente Node/TS con el Claude Agent SDK +
  el MCP de Lovable + modelo claude-fable-5, que corre por cron en un VPS y construye las webs de
  cliente EN LOVABLE vía su MCP, escribiendo en Supabase con la service key.
- Runtime LLM: Claude API. Haiku 4.5 para extracción a volumen; Fable 5 para build-prompt y conducir
  Lovable. Email: Resend (dominio secundario, texto plano). Pagos: Stripe. Llamadas: ElevenLabs.

Reglas duras (innegociables):
- Todas las secrets SOLO en servidor (Edge Functions / Orquestador). Nunca en el frontend.
- Las webs de cliente se construyen en Lovable VÍA SU MCP desde el Orquestador, NO como Edge Function
  y NO con plantillas estáticas.
- El frontend público nunca inserta en DB directo: pasa por create-checkout / track-event.
- Todas las salidas de Claude en JSON estricto según los esquemas del doc (sección 10). Parsear con try/catch.
- Gate de QA obligatorio: ningún lead se contacta hasta status='approved'.
- Construye POR FASES (sección 13). No avances de fase sin que yo lo apruebe.

Tu tarea AHORA: construye solo la Fase 0 y la Fase 1.
- Fase 0: scaffold del repo (Vite/React/Tailwind/shadcn), proyecto Supabase, aplica la migración
  completa (schema + RLS de la sección 5), configura Auth (solo un operador), deja el deploy en Vercel
  listo y documenta dónde van los secrets.
- Fase 1: Edge Function ingest-leads (normaliza, dedupe por google_place_id, upsert a status='new'),
  la pantalla /import (pegar JSON o subir CSV), y la tabla de leads en /.

Método de trabajo: explica en 3-4 líneas qué vas a hacer, hazlo, y al terminar dame la lista exacta
de comandos/pasos para verificar la Fase 1 (cómo meter un lead de prueba y verlo en el panel). Luego
PARA y espera mi OK antes de la Fase 2. Trabaja de forma autónoma dentro de estas fases; solo
pregúntame si hay una decisión que de verdad necesite mi criterio.
```

---

## 17. Fuera de alcance / avisos honestos

- **Créditos de Lovable = tu mayor coste variable, y se gastan en CADA build, no solo en los que
  cierran.** Web-first significa construir ~110 webs/mes; muchas no convertirán. Asegúrate de que
  `conversión × ticket` cubre el coste de créditos de **todas**. Por eso vendes *mayor ticket*.
  *Optimización opcional:* construir una versión ligera (menos iteración = menos créditos) como gancho,
  y solo pulir a fondo tras mostrar interés. Reduce el desperdicio a la mitad.
- **Llamadas:** son ElevenLabs, no Claude/Lovable. Y 5 llamadas IA salientes/día a números scrapeados
  en España tienen tema de consentimiento/GDPR y disclosure de IA. Eyes-open; decides tú.
- **El Orquestador no es serverless corto:** un build tarda minutos. Corre en VPS/job largo.
- **Scraping y warmup de dominio de email:** externos. El sistema ingiere y envía, no scrapea ni calienta.
```


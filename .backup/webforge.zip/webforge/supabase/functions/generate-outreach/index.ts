// generate-outreach — Contrato: ARQUITECTURA_webforge_v2.md sec. 8 y 10
// Input: { lead_id, channel }. Usa brief + sites.live_url -> Claude (OUTREACH_PROMPT) ->
// inserta outreach_messages (draft). Solo para leads status='approved'.
import { createClient } from "jsr:@supabase/supabase-js@2";
import { OUTREACH_PROMPT } from "../_shared/prompts.ts";

Deno.serve(async (_req) => {
  // TODO Fase 5: cargar lead+brief+site, llamar a Claude con OUTREACH_PROMPT (JSON estricto),
  // guardar en outreach_messages.
  void OUTREACH_PROMPT;
  const _supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );
  return new Response("TODO: implementar generate-outreach", { status: 501 });
});

// create-checkout — Contrato: ARQUITECTURA_webforge_v2.md sec. 8
// Input: { lead_id, plan, contact }. Crea Stripe Checkout Session, inserta bookings (started),
// lead -> status='booked'. Devuelve { checkout_url }.
Deno.serve(async (_req) => {
  // TODO Fase 6: crear sesión Stripe con STRIPE_SECRET_KEY, insertar booking, devolver url.
  return new Response("TODO: implementar create-checkout", { status: 501 });
});

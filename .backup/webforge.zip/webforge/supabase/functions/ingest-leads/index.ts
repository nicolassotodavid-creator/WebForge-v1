// ingest-leads — Contrato: ARQUITECTURA_webforge_v2.md sec. 8
// Input: { leads: [...] } o CSV. Normaliza, dedupe por google_place_id, upsert -> status='new'.
// Valida INGEST_WEBHOOK_SECRET. Usa SUPABASE_SERVICE_ROLE_KEY.
import { createClient } from "jsr:@supabase/supabase-js@2";

Deno.serve(async (_req) => {
  // TODO Fase 1: validar secret, parsear body (JSON o CSV), normalizar campos,
  // upsert en `leads` deduplicando por google_place_id, status='new'.
  const _supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );
  return new Response("TODO: implementar ingest-leads", { status: 501 });
});

// WebForge — Orquestador (agente diario). Ver ARQUITECTURA_webforge_v2.md sec. 9.
// Corre por CRON en un VPS. Usa el Claude Agent SDK + el MCP de Lovable + modelo claude-fable-5,
// y la service key de Supabase. NO es serverless corto: un build de Lovable tarda minutos.
//
// Flujo: lee leads 'new' -> Fable hace brief -> Fable hace build-prompt ->
//        MCP de Lovable construye la web -> guarda live_url en `sites` -> lead 'site_built'.
// Las aprobaciones, el outreach y las llamadas son pasos POSTERIORES (tras el QA humano).

import { createClient } from "@supabase/supabase-js";
import { BRIEF_PROMPT, BUILD_PROMPT } from "../supabase/functions/_shared/prompts.ts";

const BATCH = Number(process.env.BATCH_SIZE ?? 5);
const BOOKING_BASE = process.env.BOOKING_BASE!;

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
);

// TODO: inicializar el agente (Claude Agent SDK) con modelo 'claude-fable-5' y el MCP de Lovable (OAuth).
// async function fable(systemPrompt: string, input: unknown): Promise<string> { ... }   // JSON o texto
// async function lovableBuild(prompt: string): Promise<{ projectId: string; liveUrl: string }> { ... } // vía MCP

async function run() {
  const { data: leads } = await supabase
    .from("leads").select("*").eq("status", "new").limit(BATCH);

  for (const lead of leads ?? []) {
    // 1) Brief
    // const brief = JSON.parse(await fable(BRIEF_PROMPT, lead));
    // await supabase.from("briefs").insert({ lead_id: lead.id, ...brief, model_used: "claude-fable-5" });
    // await supabase.from("leads").update({ status: "analyzed" }).eq("id", lead.id);

    // 2) Build-prompt (Fable escribe el prompt para Lovable)
    // const bookingUrl = `${BOOKING_BASE}?lead=${lead.id}`;
    // const buildPrompt = await fable(BUILD_PROMPT.replaceAll("{{BOOKING_URL}}", bookingUrl), { brief, lead });

    // 3) Construir en Lovable VÍA MCP -> URL en vivo
    // const { data: site } = await supabase.from("sites")
    //   .insert({ lead_id: lead.id, build_prompt: buildPrompt, status: "building" }).select().single();
    // const { projectId, liveUrl } = await lovableBuild(buildPrompt);
    // await supabase.from("sites").update({
    //   lovable_project_id: projectId, live_url: liveUrl, status: "built", built_at: new Date().toISOString(),
    // }).eq("id", site.id);

    // 4) Listo para QA
    // await supabase.from("leads").update({ status: "site_built" }).eq("id", lead.id);

    void BRIEF_PROMPT; void BUILD_PROMPT; void BOOKING_BASE; // (placeholders mientras se implementa)
    console.log(`TODO Fase 3: procesar lead ${lead.id} (${lead.name})`);
  }
}

run().catch((e) => { console.error(e); process.exit(1); });

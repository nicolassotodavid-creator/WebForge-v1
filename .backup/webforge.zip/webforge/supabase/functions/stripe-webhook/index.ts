// stripe-webhook — Contrato: ARQUITECTURA_webforge_v2.md sec. 8
// Verifica firma con STRIPE_WEBHOOK_SECRET. checkout.session.completed -> booking.paid, lead 'won'.
Deno.serve(async (_req) => {
  // TODO Fase 6: verificar firma, manejar checkout.session.completed, actualizar booking + lead.
  return new Response("TODO: implementar stripe-webhook", { status: 501 });
});

# Orquestador

Agente diario que construye las webs de cliente en Lovable. Ver `ARQUITECTURA_webforge_v2.md` sec. 9.

- **Runtime:** Node/TS con el Claude Agent SDK + el MCP de Lovable (OAuth) + modelo `claude-fable-5`.
- **Cómo corre:** cron en un VPS (un build de Lovable tarda minutos → nada de serverless corto).
- **Escribe en Supabase** con `SUPABASE_SERVICE_ROLE_KEY`.
- Implementación: **Fase 3** del orden de construcción.

Pendiente de implementar (TODOs en `run.ts`): el cliente del Agent SDK (`fable`) y el puente al MCP
de Lovable (`lovableBuild`). Fija una vez el *workspace knowledge* en Lovable para consistencia de marca.
